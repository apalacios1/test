# Create a folder
mkdir LearnPython

# Navigate into the folder
cd LearnPython

# Create a Python File
touch Quick.py

# Open the file (Mac / Windows)
Open / explorer Quick.py
